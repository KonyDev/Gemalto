define({
    /*
      This is an auto generated file and any modifications to it may result in corruption of the action sequence.
    */
    /** postShow defined for faceid **/
    AS_FlexContainer_e37cad2a43704ce5a43db0cab1f2db84: function AS_FlexContainer_e37cad2a43704ce5a43db0cab1f2db84(eventobject) {
        var self = this;
        this.configuration();
    }
});